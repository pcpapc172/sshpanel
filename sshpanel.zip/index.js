#!/usr/bin/env node
'use strict';

/**
 * ServerPanel Backend — server.js
 *
 * Runs as root (or with sudo). Manages SSH users without restarting sshd.
 * Uses sshd -T to validate config + kill -HUP to reload.
 * Auto-backs up the DB to JSON every 10 minutes and on every write.
 *
 * Start:  sudo node server.js
 * Port:   3000 (change PORT env var to override)
 */

const express  = require('express');
const cors     = require('cors');
const { execSync, exec } = require('child_process');
const fs       = require('fs');
const path     = require('path');
const crypto   = require('crypto');
const os       = require('os');

// ─────────────────────────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────────────────────────
const PORT        = parseInt(process.env.PORT || 3000);
const SUB_PORT    = parseInt(process.env.SUB_PORT || PORT + 1); // subscription portal port
const DATA_FILE   = process.env.DATA_FILE  || path.join(__dirname, 'users.json');
const BACKUP_DIR  = process.env.BACKUP_DIR || path.join(__dirname, 'backups');
const SSHD_CONF   = process.env.SSHD_CONF  || '/etc/ssh/sshd_config';
const SSHD_CONF_D = process.env.SSHD_CONF_D|| '/etc/ssh/sshd_config.d';
const PANEL_FILE  = process.env.PANEL_FILE || path.join(__dirname, 'panel.html');
const SUB_FILE    = process.env.SUB_FILE   || path.join(__dirname, 'sub.html');
const DRY_RUN     = process.env.DRY_RUN === '1';   // set DRY_RUN=1 to skip real shell cmds (dev mode)
const SERVER_HOST = process.env.SERVER_HOST || ''; // optional: override the host shown in sub links

// ─────────────────────────────────────────────────────────────────────────────
// Panel auth (simple single-admin password, stored hashed in users.json meta)
// ─────────────────────────────────────────────────────────────────────────────
const PANEL_SECRET = process.env.PANEL_SECRET || '';  // set env var to pre-configure

function hashPass(p) {
  return crypto.createHash('sha256').update('sp:' + p).digest('hex');
}

function getPanelHash() {
  return db.meta && db.meta.panelPassHash || null;
}

function checkPanelAuth(req) {
  const hash = getPanelHash();
  if (!hash) return true;   // no password set yet — allow setup
  const token = req.headers['x-panel-token'] || '';
  return token === hash;
}

function requireAuth(req, res, next) {
  if (!checkPanelAuth(req)) {
    return res.status(401).json({ ok: false, error: 'Unauthorized' });
  }
  next();
}

// ─────────────────────────────────────────────────────────────────────────────
// Subscription token helpers
// Each user gets a unique random token stored in users.json.
// The token is used to access the public subscription portal on SUB_PORT.
// ─────────────────────────────────────────────────────────────────────────────
function genSubToken() {
  return crypto.randomBytes(24).toString('hex'); // 48-char hex token
}

function ensureSubToken(user) {
  if (!user.subToken) {
    user.subToken = genSubToken();
  }
  return user.subToken;
}

function getSubLink(user, req) {
  const token = ensureSubToken(user);
  // Determine the server host to put in the link
  let host = SERVER_HOST;
  if (!host && req) {
    host = req.hostname || req.headers.host?.split(':')[0] || 'localhost';
  }
  if (!host) host = 'localhost';
  return `http://${host}:${SUB_PORT}/sub.html?token=${token}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────
function sh(cmd, opts = {}) {
  if (DRY_RUN) { console.log('[DRY]', cmd); return ''; }
  return execSync(cmd, { encoding: 'utf8', stdio: ['pipe','pipe','pipe'], ...opts }).trim();
}

function shAsync(cmd) {
  return new Promise((res, rej) =>
    exec(cmd, (err, stdout, stderr) =>
      err ? rej(new Error(stderr || err.message)) : res(stdout.trim())
    )
  );
}

function userExists(username) {
  try { sh(`id "${username}"`); return true; } catch { return false; }
}

function genPassword(len = 14) {
  return crypto.randomBytes(len).toString('base64').replace(/[^a-zA-Z0-9]/g,'').slice(0, len);
}

function ts() { return new Date().toISOString(); }

// ─────────────────────────────────────────────────────────────────────────────
// DB  (flat JSON, written to disk on every mutation)
// ─────────────────────────────────────────────────────────────────────────────
let db = { users: [], meta: { created: ts(), version: 1 } };

function loadDB() {
  if (fs.existsSync(DATA_FILE)) {
    try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
    catch (e) { console.error('DB load failed, starting fresh:', e.message); }
  }
}

function saveDB() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  scheduleBackup();
}

// ─────────────────────────────────────────────────────────────────────────────
// Auto-backup
// ─────────────────────────────────────────────────────────────────────────────
let backupDebounce;
const BACKUP_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes max
const MAX_BACKUPS = 48; // keep last 48 snapshots (~8h at 10min)

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

function writeBackup() {
  const fname = `backup-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
  const fpath = path.join(BACKUP_DIR, fname);
  fs.writeFileSync(fpath, JSON.stringify({ ...db, _backupAt: ts() }, null, 2));

  // Prune old backups
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('backup-') && f.endsWith('.json'))
    .sort();
  while (files.length > MAX_BACKUPS) {
    fs.unlinkSync(path.join(BACKUP_DIR, files.shift()));
  }
  console.log('[backup]', fname);
}

function scheduleBackup() {
  clearTimeout(backupDebounce);
  backupDebounce = setTimeout(writeBackup, 5000); // debounced — writes 5s after last change
}

// Periodic backup every 10 min regardless
setInterval(writeBackup, BACKUP_INTERVAL_MS);

// ─────────────────────────────────────────────────────────────────────────────
// SSH config helpers (per-user drop-in files, no sshd restart)
// ─────────────────────────────────────────────────────────────────────────────

// Write /etc/ssh/sshd_config.d/panel-<username>.conf
function writeUserSSHConf(user) {
  if (!fs.existsSync(SSHD_CONF_D)) {
    fs.mkdirSync(SSHD_CONF_D, { recursive: true });
    // Make sure sshd_config includes the dir
    const main = fs.readFileSync(SSHD_CONF, 'utf8');
    if (!main.includes('Include /etc/ssh/sshd_config.d')) {
      fs.appendFileSync(SSHD_CONF, '\nInclude /etc/ssh/sshd_config.d/*.conf\n');
    }
  }

  const lines = [
    `# ServerPanel — managed config for ${user.username} — DO NOT EDIT MANUALLY`,
    `Match User ${user.username}`,
    `    AllowTcpForwarding ${user.noforward ? 'no' : 'yes'}`,
    `    X11Forwarding ${user.x11 ? 'yes' : 'no'}`,
    `    MaxSessions ${user.maxConn}`,
  ];

  if (user.ipWhite && user.ips) {
    // AllowUsers with address filter (openssh 9.0+)
    // We implement IP restriction via PAM/pf or a Match Address block
    lines.push(`    # IP restriction: ${user.ips}`);
  }
  if (user.noforward) {
    lines.push(`    PermitTTY no`);
  }
  if (user.banner) {
    lines.push(`    Banner /etc/ssh/banners/${user.username}.txt`);
  }

  const confPath = path.join(SSHD_CONF_D, `panel-${user.username}.conf`);
  if (!DRY_RUN) fs.writeFileSync(confPath, lines.join('\n') + '\n');
  else console.log('[DRY] write', confPath, lines);
}

function removeUserSSHConf(username) {
  const confPath = path.join(SSHD_CONF_D, `panel-${username}.conf`);
  if (!DRY_RUN && fs.existsSync(confPath)) fs.unlinkSync(confPath);
}

// Reload sshd config without restarting (sends HUP to sshd master process)
function reloadSSHD() {
  if (DRY_RUN) { console.log('[DRY] reload sshd'); return; }
  try {
    // Validate config first
    sh('sshd -t');
    // HUP the master sshd — existing sessions survive, new connections pick up new config
    sh("kill -HUP $(cat /var/run/sshd.pid 2>/dev/null || pgrep -o sshd)");
    console.log('[sshd] reloaded via HUP');
  } catch (e) {
    console.error('[sshd] reload error:', e.message);
    throw new Error('sshd config invalid or reload failed: ' + e.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Linux user management
// ─────────────────────────────────────────────────────────────────────────────
function createLinuxUser(user, password) {
  const shell = user.nologin ? '/usr/sbin/nologin' : '/bin/bash';
  if (!userExists(user.username)) {
    sh(`useradd -s "${shell}" -M -N "${user.username}"`);
  } else {
    sh(`usermod -s "${shell}" "${user.username}"`);
  }
  // Set password via chpasswd
  if (!DRY_RUN) {
    const proc = require('child_process').spawnSync(
      'chpasswd', [], { input: `${user.username}:${password}`, encoding: 'utf8' }
    );
    if (proc.status !== 0) throw new Error('chpasswd failed: ' + proc.stderr);
  } else {
    console.log('[DRY] chpasswd', user.username);
  }

  // Set account expiry
  if (user.expiry) {
    sh(`chage -E "${user.expiry}" "${user.username}"`);
  }

  // Lock account immediately if disabled
  if (user.status === 'disabled') sh(`usermod -L "${user.username}"`);
}

function deleteLinuxUser(username) {
  if (userExists(username)) {
    sh(`userdel -f "${username}" 2>/dev/null || true`);
  }
}

function lockLinuxUser(username) {
  if (userExists(username)) sh(`usermod -L "${username}"`);
}

function unlockLinuxUser(username) {
  if (userExists(username)) sh(`usermod -U "${username}"`);
}

// Kill all live SSH sessions for a user immediately
// Uses pkill to send SIGTERM to every sshd child process owned by that user,
// which causes the SSH server to close the TCP connection right away.
function killUserSessions(username) {
  if (DRY_RUN) { console.log('[DRY] killUserSessions', username); return; }
  try {
    // pkill -u <username> sshd  — kills the per-connection sshd worker processes
    sh(`pkill -TERM -u "${username}" sshd 2>/dev/null || true`);
    // Also clean up activeSessions map entries for this user
    for (const [key, s] of activeSessions) {
      if (s.username === username) {
        // Accumulate any remaining bytes before dropping the session record
        const { txBytes, rxBytes } = readSessionCounters(s.clientIP, s.sport);
        const txGB = (txBytes / 1e9) - (s._lastTxSnap || 0);
        const rxGB = (rxBytes / 1e9) - (s._lastRxSnap || 0);
        if (txGB > 0 || rxGB > 0) {
          const u = db.users.find(x => x.username === username);
          if (u) {
            u.dataOut = Math.round(((u.dataOut || 0) + txGB) * 1000) / 1000;
            u.dataIn  = Math.round(((u.dataIn  || 0) + rxGB) * 1000) / 1000;
          }
        }
        // Remove iptables rules for this session
        try { sh(`iptables -D PANEL_OUT -d ${s.clientIP} -p tcp --dport ${s.sport} -j RETURN`); } catch {}
        try { sh(`iptables -D PANEL_IN  -s ${s.clientIP} -p tcp --sport ${s.sport} -j RETURN`); } catch {}
        activeSessions.delete(key);
      }
    }
    console.log('[kill] sessions terminated for', username);
  } catch (e) {
    console.warn('[kill] killUserSessions failed for', username, ':', e.message);
  }
}

function resetLinuxPassword(username) {
  const pwd = genPassword();
  if (!DRY_RUN) {
    const proc = require('child_process').spawnSync(
      'chpasswd', [], { input: `${username}:${pwd}`, encoding: 'utf8' }
    );
    if (proc.status !== 0) throw new Error('chpasswd failed: ' + proc.stderr);
  } else {
    console.log('[DRY] reset password for', username);
  }
  return pwd;
}

// ────────────────────────────────────────────��────────────────────────────────
// Per-user traffic accounting via iptables (IP:sport rules)
//
// SSH tunnel traffic cannot be counted with --uid-owner because the kernel
// associates tunnel packets with the remote client's IP/port, not the Linux
// user UID.  The correct method (as described by newspaint.wordpress.com and
// pranavk.me) is:
//   1. Watch /var/log/auth.log for "Accepted password/publickey for <user>
//      from <clientIP> port <sport>"  → insert iptables rules for that IP:sport
//   2. Watch for "Disconnected from <user>" / "session closed for user <user>"
//      → read+accumulate the byte counters, then delete the rules
//
// Each live session gets TWO rules (one in PANEL_IN, one in PANEL_OUT) that
// match on the client's remote IP and source port, so every byte of the SSH
// tunnel is counted regardless of which Linux process handles it.
// ─────────────────────────────────────────────────────────────────────────────

// activeSessions: Map<sessionKey, { username, clientIP, sport, ruleAdded }>
// sessionKey = `${clientIP}:${sport}`
const activeSessions = new Map();

function ensureIptablesChains() {
  if (DRY_RUN) return;
  try {
    try { sh('iptables -N PANEL_OUT 2>/dev/null'); } catch {}
    try { sh('iptables -N PANEL_IN  2>/dev/null'); } catch {}
    // SSH tunnel traffic flows through INPUT/OUTPUT (not FORWARD — no IP forwarding needed)
    try { sh('iptables -C OUTPUT -j PANEL_OUT 2>/dev/null'); }
    catch { sh('iptables -I OUTPUT -j PANEL_OUT'); }
    try { sh('iptables -C INPUT  -j PANEL_IN  2>/dev/null'); }
    catch { sh('iptables -I INPUT  -j PANEL_IN');  }
  } catch (e) {
    console.warn('[iptables] chain setup failed:', e.message);
  }
}

// Called when a user connects — inserts per-session IP:sport iptables rules
function addSessionRules(username, clientIP, sport) {
  const key = `${clientIP}:${sport}`;
  if (activeSessions.has(key)) return; // already tracked
  if (DRY_RUN) {
    console.log('[DRY] addSessionRules', username, clientIP, sport);
    activeSessions.set(key, { username, clientIP, sport, ruleAdded: false });
    return;
  }
  try {
    // Outbound: server → client (server replies back to client's source port)
    sh(`iptables -A PANEL_OUT -d ${clientIP} -p tcp --dport ${sport} -j RETURN`);
    // Inbound: client → server (packets arriving from client's source port)
    sh(`iptables -A PANEL_IN  -s ${clientIP} -p tcp --sport ${sport} -j RETURN`);
    activeSessions.set(key, { username, clientIP, sport, ruleAdded: true });
    console.log('[session] rules added for', username, key);
  } catch (e) {
    console.warn('[iptables] addSessionRules failed:', username, key, e.message);
    activeSessions.set(key, { username, clientIP, sport, ruleAdded: false });
  }
}

// Read byte counters for a specific session rule, returns { txBytes, rxBytes }
function readSessionCounters(clientIP, sport) {
  if (DRY_RUN) return { txBytes: 0, rxBytes: 0 };
  try {
    // OUT chain = bytes sent to client (server TX = client RX = "download" for the client)
    const outRaw = sh(`iptables -L PANEL_OUT -v -n -x 2>/dev/null`);
    // IN chain  = bytes received from client (server RX = client TX = "upload" from client)
    const inRaw  = sh(`iptables -L PANEL_IN  -v -n -x 2>/dev/null`);

    const extractBytes = (raw, ip, port) => {
      let bytes = 0;
      raw.split('\n').forEach(line => {
        // iptables -v output: pkts bytes target prot opt in out source destination
        // We match destination (OUT) or source (IN) IP and the port
        if (line.includes(ip) && line.includes(String(port))) {
          const m = line.match(/^\s*\d+\s+(\d+)\s+/);
          if (m) bytes += parseInt(m[1]) || 0;
        }
      });
      return bytes;
    };

    const txBytes = extractBytes(outRaw, clientIP, sport); // sent to client
    const rxBytes = extractBytes(inRaw,  clientIP, sport); // received from client
    return { txBytes, rxBytes };
  } catch { return { txBytes: 0, rxBytes: 0 }; }
}

// Called when a user disconnects — reads counters, accumulates into DB, removes rules
function removeSessionRules(username, clientIP, sport) {
  const key = `${clientIP}:${sport}`;
  const session = activeSessions.get(key);
  if (!session) return;

  // Read counters before deleting rules
  const { txBytes, rxBytes } = readSessionCounters(clientIP, sport);
  const txGB = txBytes / 1e9;
  const rxGB = rxBytes / 1e9;
  const totalGB = txGB + rxGB;

  // Accumulate into user's DB record
  const u = db.users.find(x => x.username === username);
  if (u && totalGB > 0) {
    u.dataUsed   = Math.round(((u.dataUsed  || 0) + totalGB) * 1000) / 1000;
    u.dataOut    = Math.round(((u.dataOut   || 0) + txGB)    * 1000) / 1000; // bytes sent to client
    u.dataIn     = Math.round(((u.dataIn    || 0) + rxGB)    * 1000) / 1000; // bytes received from client
    u.lastSeen   = new Date().toISOString().replace('T', ' ').slice(0, 19);
    saveDB();
    checkExpiry();
    console.log('[session] closed', username, key, `+${totalGB.toFixed(4)} GB (tx:${txGB.toFixed(4)} rx:${rxGB.toFixed(4)})`);
  }

  // Remove iptables rules
  if (session.ruleAdded && !DRY_RUN) {
    try { sh(`iptables -D PANEL_OUT -d ${clientIP} -p tcp --dport ${sport} -j RETURN`); } catch {}
    try { sh(`iptables -D PANEL_IN  -s ${clientIP} -p tcp --sport ${sport} -j RETURN`); } catch {}
  }

  activeSessions.delete(key);
}

// Legacy stubs — kept so boot/delete code paths don't break
function addIptablesUser(username) { /* no-op: rules are now per-session not per-user */ }
function removeIptablesUser(username) {
  // On user delete, clean up any live sessions for this user
  for (const [key, s] of activeSessions) {
    if (s.username === username) removeSessionRules(username, s.clientIP, s.sport);
  }
}

// Called periodically — snapshot in-flight counters for still-active sessions
// (so a long-running session's data isn't lost if the server restarts)
function updateDataUsage() {
  try {
    ensureIptablesChains();
    // For each active session, peek at current bytes without removing rules
    for (const [key, s] of activeSessions) {
      const { txBytes, rxBytes } = readSessionCounters(s.clientIP, s.sport);
      const txGB = txBytes / 1e9;
      const rxGB = rxBytes / 1e9;
      const totalGB = txGB + rxGB;
      if (totalGB < 0.00001) continue;

      const u = db.users.find(x => x.username === s.username);
      if (!u) continue;

      // Only update if the counter has grown since last snapshot
      const prevSnap = s._lastSnap || 0;
      if (totalGB <= prevSnap) continue;
      const delta = totalGB - prevSnap;
      s._lastSnap = totalGB;

      u.dataUsed = Math.round(((u.dataUsed || 0) + delta) * 1000) / 1000;
      u.dataOut  = Math.round(((u.dataOut  || 0) + (txGB - (s._lastTxSnap||0))) * 1000) / 1000;
      u.dataIn   = Math.round(((u.dataIn   || 0) + (rxGB - (s._lastRxSnap||0))) * 1000) / 1000;
      s._lastTxSnap = txGB;
      s._lastRxSnap = rxGB;
    }
    if (activeSessions.size > 0) { saveDB(); checkExpiry(); }
  } catch (e) {
    console.warn('[data-accounting] updateDataUsage error:', e.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// auth.log watcher — detects SSH logins and disconnections
// ─────────────────────────────────────────────────────────────────────────────
const AUTH_LOG = '/var/log/auth.log';

function startAuthLogWatcher() {
  if (DRY_RUN) { console.log('[auth-watcher] skipped in DRY_RUN'); return; }
  if (!fs.existsSync(AUTH_LOG)) {
    console.warn('[auth-watcher] ' + AUTH_LOG + ' not found — trying journalctl fallback');
    startJournalWatcher();
    return;
  }

  let fileSize = fs.statSync(AUTH_LOG).size;

  fs.watch(AUTH_LOG, { persistent: false }, (event) => {
    try {
      const stat = fs.statSync(AUTH_LOG);
      if (stat.size <= fileSize) { fileSize = stat.size; return; } // truncated/rotated
      const fd = fs.openSync(AUTH_LOG, 'r');
      const buf = Buffer.alloc(stat.size - fileSize);
      fs.readSync(fd, buf, 0, buf.length, fileSize);
      fs.closeSync(fd);
      fileSize = stat.size;
      processAuthLines(buf.toString('utf8'));
    } catch (e) {
      console.warn('[auth-watcher] read error:', e.message);
    }
  });

  console.log('[auth-watcher] watching', AUTH_LOG);
}

function startJournalWatcher() {
  // Fallback: tail journalctl -fu ssh (systemd systems without /var/log/auth.log)
  const { spawn } = require('child_process');
  const proc = spawn('journalctl', ['-fu', 'ssh', '--output=short-iso', '--no-pager'], {
    stdio: ['ignore', 'pipe', 'ignore']
  });
  let buf = '';
  proc.stdout.on('data', chunk => {
    buf += chunk.toString();
    const lines = buf.split('\n');
    buf = lines.pop();
    processAuthLines(lines.join('\n'));
  });
  proc.on('exit', () => {
    // try sshd service name
    const proc2 = spawn('journalctl', ['-fu', 'sshd', '--output=short-iso', '--no-pager'], {
      stdio: ['ignore', 'pipe', 'ignore']
    });
    let buf2 = '';
    proc2.stdout.on('data', chunk => {
      buf2 += chunk.toString();
      const lines = buf2.split('\n');
      buf2 = lines.pop();
      processAuthLines(lines.join('\n'));
    });
  });
  console.log('[auth-watcher] using journalctl fallback');
}

// Parse auth.log lines for connect/disconnect events
function processAuthLines(text) {
  text.split('\n').forEach(line => {
    if (!line.trim()) return;

    // LOGIN: "Accepted password for alice from 1.2.3.4 port 54321 ssh2"
    //        "Accepted publickey for alice from 1.2.3.4 port 54321 ssh2"
    const loginM = line.match(/Accepted (?:password|publickey|keyboard-interactive\/pam) for (\S+) from ([\d.a-fA-F:]+) port (\d+)/);
    if (loginM) {
      const [, username, clientIP, sportStr] = loginM;
      const sport = parseInt(sportStr);
      if (db.users.find(u => u.username === username)) {
        addSessionRules(username, clientIP, sport);
        // Update session count
        const u = db.users.find(x => x.username === username);
        if (u) { u.sessions = (u.sessions || 0) + 1; saveDB(); }
      }
      return;
    }

    // DISCONNECT: "Disconnected from authenticating user alice 1.2.3.4 port 54321"
    //             "Disconnected from user alice 1.2.3.4 port 54321"
    //             "Connection closed by authenticating user alice 1.2.3.4 port 54321"
    //             "Connection closed by user alice 1.2.3.4 port 54321"
    const discM = line.match(/(?:Disconnected from|Connection closed by)(?: authenticating)?(?: user)? (\S+) ([\d.a-fA-F:]+) port (\d+)/);
    if (discM) {
      const [, username, clientIP, sportStr] = discM;
      const sport = parseInt(sportStr);
      removeSessionRules(username, clientIP, sport);
      // Decrement session count
      const u = db.users.find(x => x.username === username);
      if (u) { u.sessions = Math.max(0, (u.sessions || 1) - 1); saveDB(); }
      return;
    }

    // Also handle pam_unix session closed (belt+suspenders)
    const pamM = line.match(/pam_unix\(sshd:session\): session closed for user (\S+)/);
    if (pamM) {
      const username = pamM[1];
      // We don't have port from PAM lines, so close all sessions for this user
      for (const [key, s] of activeSessions) {
        if (s.username === username) removeSessionRules(username, s.clientIP, s.sport);
      }
    }
  });
}

// Also expose a POST endpoint so panel can trigger a manual refresh
// (registered further down after app is created)

// ─────────────────────────────────────────────────────────────────────────────
// Traffic tracking (reads from /proc/net/dev — per-iface, not per-user)
// For per-user accounting we use iptables if available
// ─────────────────────────────────────────────────────────────────────────────
function getSystemTraffic() {
  try {
    const raw = fs.readFileSync('/proc/net/dev', 'utf8');
    let rx = 0, tx = 0;
    raw.split('\n').slice(2).forEach(line => {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 10 && parts[0] !== 'lo:') {
        rx += parseInt(parts[1]) || 0;
        tx += parseInt(parts[9]) || 0;
      }
    });
    return { rx: Math.round(rx / 1e9 * 100) / 100, tx: Math.round(tx / 1e9 * 100) / 100 };
  } catch { return { rx: 0, tx: 0 }; }
}

function getSystemStats() {
  const uptime = os.uptime();
  const d = Math.floor(uptime / 86400);
  const h = Math.floor((uptime % 86400) / 3600);
  const loadAvg = os.loadavg()[0].toFixed(2);
  const totalMem = (os.totalmem() / 1e9).toFixed(1);
  const freeMem  = (os.freemem()  / 1e9).toFixed(1);
  const usedMem  = ((os.totalmem() - os.freemem()) / 1e9).toFixed(1);
  return { uptime: `${d}d ${h}h`, load: loadAvg, totalMem, freeMem, usedMem };
}

// ─────────────────────────────────────────────────────────────────────────────
// Express API
// ─────────────────────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// ── POST /api/auth/login ─────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { password } = req.body || {};
  if (!password) return res.status(400).json({ ok: false, error: 'Password required' });
  const hash = getPanelHash();
  if (!hash) {
    // First-time setup: set the password
    db.meta.panelPassHash = hashPass(password);
    saveDB();
    console.log('[auth] panel password set');
    return res.json({ ok: true, token: db.meta.panelPassHash, firstTime: true });
  }
  const attempt = hashPass(password);
  if (attempt !== hash) return res.status(401).json({ ok: false, error: 'Wrong password' });
  res.json({ ok: true, token: hash });
});

// ── POST /api/auth/change-password ───────────────────────────────────────
app.post('/api/auth/change-password', requireAuth, (req, res) => {
  const { newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 6)
    return res.status(400).json({ ok: false, error: 'Password must be at least 6 characters' });
  db.meta.panelPassHash = hashPass(newPassword);
  saveDB();
  res.json({ ok: true, token: db.meta.panelPassHash });
});

// ── GET /api/auth/status ──────────────────────────────────────────────────
app.get('/api/auth/status', (req, res) => {
  res.json({ ok: true, hasPassword: !!getPanelHash() });
});

// Serve favicon
app.get('/favicon.ico', (req, res) => {
  // Simple SVG favicon — green server icon matching the panel theme
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
    <rect width="32" height="32" rx="7" fill="#00e5a0"/>
    <path d="M6 10h20v4H6zm0 8h20v4H6z" fill="#0d0f11"/>
    <circle cx="22" cy="12" r="1.5" fill="#0d0f11"/>
    <circle cx="22" cy="20" r="1.5" fill="#0d0f11"/>
  </svg>`;
  const buf = Buffer.from(svg);
  res.setHeader('Content-Type', 'image/svg+xml');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(buf);
});

// Serve panel.html at root
app.get('/', (req, res) => {
  if (fs.existsSync(PANEL_FILE)) {
    res.sendFile(PANEL_FILE);
  } else {
    res.send('<h2>panel.html not found. Place it in the same folder as server.js.</h2>');
  }
});

// ── GET /api/users ────────────────────────────────────────────────────────
app.get('/api/users', requireAuth, (req, res) => {
  // Attach live session details to each user before returning
  const onlineMap = new Map(); // username -> [{ ip, port }]
  for (const s of activeSessions.values()) {
    if (!onlineMap.has(s.username)) onlineMap.set(s.username, []);
    onlineMap.get(s.username).push({ ip: s.clientIP, port: s.sport });
  }
  const usersOut = db.users.map(u => ({
    ...u,
    online:          onlineMap.has(u.username),
    onlineSessions:  onlineMap.get(u.username) || [],
    sessions:        (onlineMap.get(u.username) || []).length,
    subLink:         getSubLink(u, req),
  }));
  saveDB(); // persist any newly-created sub tokens
  res.json({ ok: true, users: usersOut });
});

// ── POST /api/users  (create) ─────────────────────────────────────────────
app.post('/api/users', requireAuth, (req, res) => {
  try {
    const b = req.body;
    if (!b.username || !/^[a-z_][a-z0-9_-]{0,31}$/.test(b.username))
      return res.status(400).json({ ok: false, error: 'Invalid username' });
    if (db.users.find(u => u.username === b.username))
      return res.status(409).json({ ok: false, error: 'Username already exists' });

    const password = b.password || genPassword();
    const now = new Date().toISOString().split('T')[0];

    const user = {
      id:         Date.now(),
      username:   b.username,
      password:   password,
      port:       parseInt(b.port)    || 22,
      status:     'active',
      dataUsed:   0,
      dataIn:     0,
      dataOut:    0,
      dataLimit:  parseFloat(b.dataLimit)  || 0,
      expiry:     b.expiry || '',
      maxConn:    parseInt(b.maxConn)  || 2,
      nologin:    b.nologin !== false,
      noforward:  !!b.noforward,
      x11:        !!b.x11,
      lastSeen:   'never',
      sessions:   0,
      created:    now,
      ipWhite:    !!b.ipWhite,
      ips:        b.ips || '',
      speedLimit: parseInt(b.speedLimit) || 0,
      subToken:   genSubToken(),
    };

    createLinuxUser(user, password);
    writeUserSSHConf(user);
    reloadSSHD();
    ensureIptablesChains();
    addIptablesUser(user.username);

    db.users.push(user);
    saveDB();

    res.json({ ok: true, user, password }); // password returned once
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── PUT /api/users/:id  (update) ──────────────────────────────────────────
app.put('/api/users/:id', requireAuth, (req, res) => {
  try {
    const id  = parseInt(req.params.id);
    const idx = db.users.findIndex(u => u.id === id);
    if (idx < 0) return res.status(404).json({ ok: false, error: 'User not found' });

    const u = db.users[idx];
    const b = req.body;

    // Apply field updates
    const fields = ['port','dataLimit','expiry','maxConn','nologin',
                    'noforward','x11','ipWhite','ips','speedLimit','status'];
    fields.forEach(f => { if (b[f] !== undefined) u[f] = b[f]; });

    // Update shell if nologin changed
    const shell = u.nologin ? '/usr/sbin/nologin' : '/bin/bash';
    sh(`usermod -s "${shell}" "${u.username}"`);

    // Update expiry
    if (u.expiry) sh(`chage -E "${u.expiry}" "${u.username}"`);

    // Lock/unlock
    if (u.status === 'disabled') lockLinuxUser(u.username);
    else unlockLinuxUser(u.username);

    // Update SSH conf & reload
    writeUserSSHConf(u);
    reloadSSHD();

    // Password change
    if (b.password) {
      const proc = require('child_process').spawnSync(
        'chpasswd', [], { input: `${u.username}:${b.password}`, encoding: 'utf8' }
      );
      if (!DRY_RUN && proc.status !== 0) throw new Error('chpasswd failed');
      u.password = b.password;
    }

    db.users[idx] = u;
    saveDB();
    res.json({ ok: true, user: u });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── DELETE /api/users/:id ─────────────────────────────────────────────────
app.delete('/api/users/:id', requireAuth, (req, res) => {
  try {
    const id  = parseInt(req.params.id);
    const idx = db.users.findIndex(u => u.id === id);
    if (idx < 0) return res.status(404).json({ ok: false, error: 'User not found' });

    const username = db.users[idx].username;
    deleteLinuxUser(username);
    removeUserSSHConf(username);
    removeIptablesUser(username);
    reloadSSHD();

    db.users.splice(idx, 1);
    saveDB();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── POST /api/users/:id/reset-password ───────────────────────────────────
app.post('/api/users/:id/reset-password', requireAuth, (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const u  = db.users.find(u => u.id === id);
    if (!u) return res.status(404).json({ ok: false, error: 'User not found' });
    const pwd = resetLinuxPassword(u.username);
    u.password = pwd;
    saveDB();
    res.json({ ok: true, password: pwd });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── POST /api/users/:id/toggle ────────────────────────────────────────────
app.post('/api/users/:id/toggle', requireAuth, (req, res) => {
  try {
    const id  = parseInt(req.params.id);
    const idx = db.users.findIndex(u => u.id === id);
    if (idx < 0) return res.status(404).json({ ok: false, error: 'User not found' });
    const u = db.users[idx];
    u.status = u.status === 'disabled' ? 'active' : 'disabled';
    if (u.status === 'disabled') lockLinuxUser(u.username);
    else unlockLinuxUser(u.username);
    saveDB();
    res.json({ ok: true, status: u.status });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── POST /api/users/import ────────────────────────────────────────────────
app.post('/api/users/import', requireAuth, (req, res) => {
  try {
    const list = req.body.users;
    if (!Array.isArray(list)) return res.status(400).json({ ok: false, error: 'users must be an array' });

    let imported = 0, skipped = 0;
    for (const u of list) {
      if (!u || !u.username) { skipped++; continue; }
      if (db.users.find(x => x.username === u.username)) { skipped++; continue; }

      // Sanitise — keep only known safe fields, don't trust imported IDs
      const now = new Date().toISOString().split('T')[0];
      const record = {
        id:         Date.now() + imported,
        username:   u.username,
        port:       parseInt(u.port)       || 22,
        status:     ['active','disabled','expired'].includes(u.status) ? u.status : 'active',
        dataUsed:   parseFloat(u.dataUsed) || 0,
        dataIn:     parseFloat(u.dataIn)    || 0,
        dataOut:    parseFloat(u.dataOut)   || 0,
        dataLimit:  parseFloat(u.dataLimit)|| 0,
        expiry:     u.expiry     || '',
        maxConn:    parseInt(u.maxConn)    || 2,
        nologin:    u.nologin !== false,
        noforward:  !!u.noforward,
        x11:        !!u.x11,
        lastSeen:   u.lastSeen   || 'never',
        sessions:   0,
        created:    u.created    || now,
        ipWhite:    !!u.ipWhite,
        ips:        u.ips        || '',
        speedLimit: parseInt(u.speedLimit) || 0,
      };
      db.users.push(record);
      imported++;
    }

    if (imported > 0) saveDB();
    res.json({ ok: true, imported, skipped });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});


app.post('/api/users/:id/reset-data', requireAuth, (req, res) => {
  try {
    const id  = parseInt(req.params.id);
    const idx = db.users.findIndex(u => u.id === id);
    if (idx < 0) return res.status(404).json({ ok: false, error: 'User not found' });
    db.users[idx].dataUsed = 0;
    db.users[idx].dataIn  = 0;
    db.users[idx].dataOut = 0;
    // Re-activate if it was disabled only due to data limit
    const u = db.users[idx];
    if (u.status === 'disabled' && u.dataLimit > 0) {
      u.status = 'active';
      unlockLinuxUser(u.username);
    }
    saveDB();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── POST /api/data-update ─────────────────────────────────────────────────
// Manual trigger from panel to flush iptables counters into dataUsed
app.post('/api/data-update', requireAuth, (req, res) => {
  try { updateDataUsage(); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});


app.get('/api/stats', requireAuth, (req, res) => {
  const sys    = getSystemStats();
  const traffic= getSystemTraffic();
  const active = db.users.filter(u => u.status === 'active').length;
  const expiring = db.users.filter(u => {
    if (!u.expiry) return false;
    const diff = (new Date(u.expiry) - Date.now()) / (1000 * 86400);
    return diff >= 0 && diff <= 7;
  }).length;
  const totalData = db.users.reduce((s, u) => s + (u.dataUsed || 0), 0);
  res.json({ ok: true, sys, traffic, users: db.users.length, active, expiring, totalData: Math.round(totalData * 100) / 100 });
});

// ── GET /api/backups ──────────────────────────────────────────────────────
app.get('/api/backups', requireAuth, (req, res) => {
  try {
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('backup-') && f.endsWith('.json'))
      .sort().reverse()
      .map(f => {
        const stat = fs.statSync(path.join(BACKUP_DIR, f));
        return { name: f, size: stat.size, mtime: stat.mtime };
      });
    res.json({ ok: true, backups: files });
  } catch (e) {
    res.json({ ok: true, backups: [] });
  }
});

// ── GET /api/backups/:name ────────────────────────────────────────────────
app.get('/api/backups/:name', requireAuth, (req, res) => {
  const safe = path.basename(req.params.name);
  const fpath = path.join(BACKUP_DIR, safe);
  if (!fs.existsSync(fpath)) return res.status(404).json({ ok: false, error: 'Not found' });
  res.setHeader('Content-Disposition', `attachment; filename="${safe}"`);
  res.setHeader('Content-Type', 'application/json');
  res.send(fs.readFileSync(fpath));
});

// ── POST /api/backups/now ─────────────────────────────────────────────────
app.post('/api/backups/now', requireAuth, (req, res) => {
  try { writeBackup(); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ── POST /api/backups/restore ─────────────────────────────────────────────
app.post('/api/backups/restore', requireAuth, (req, res) => {
  try {
    const { name } = req.body;
    const safe = path.basename(name);
    const fpath = path.join(BACKUP_DIR, safe);
    if (!fs.existsSync(fpath)) return res.status(404).json({ ok: false, error: 'Not found' });
    const restored = JSON.parse(fs.readFileSync(fpath, 'utf8'));
    writeBackup(); // backup current state first
    db = restored;
    saveDB();
    res.json({ ok: true, users: db.users.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ── GET /api/sshd-status ──────────────────────────────────────────────────
app.get('/api/sshd-status', requireAuth, (req, res) => {
  try {
    // Try sshd first, then ssh — take only the first line of output
    let out = 'unknown';
    for (const svc of ['sshd', 'ssh']) {
      try {
        const result = sh(`systemctl is-active ${svc} 2>/dev/null`).split('\n')[0].trim();
        if (result) { out = result; break; }
      } catch {}
    }
    const pid = sh('cat /var/run/sshd.pid 2>/dev/null || pgrep -o sshd 2>/dev/null || echo 0');
    res.json({ ok: true, status: out, pid: parseInt(pid) || 0 });
  } catch (e) {
    res.json({ ok: true, status: 'unknown', pid: 0 });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// Expiry checker — runs every hour, locks/flags expired users automatically
// ─────────────────────────────────────────────────────────────────────────────
function checkExpiry() {
  let changed = false;
  db.users.forEach(u => {
    if (!u.expiry || u.status === 'expired') return;
    const diff = (new Date(u.expiry) - Date.now()) / (1000 * 86400);
    if (diff < 0 && u.status !== 'disabled') {
      u.status = 'expired';
      lockLinuxUser(u.username);
      changed = true;
      console.log('[expiry] locked', u.username);
    }
    // Data limit check
    if (u.dataLimit > 0 && u.dataUsed >= u.dataLimit && u.status === 'active') {
      u.status = 'disabled';
      lockLinuxUser(u.username);
      killUserSessions(u.username);
      changed = true;
      console.log('[data-limit] locked + killed sessions for', u.username, u.dataUsed, '>=', u.dataLimit, 'GB');
    }
    // Expiry kill — also kill live sessions if account just expired
    if (u.expiry && u.status === 'expired') {
      killUserSessions(u.username);
    }
  });
  if (changed) saveDB();
}

setInterval(checkExpiry, 60 * 60 * 1000); // every hour

// ─────────────────────────────────────────────────────────────────────────────
// Boot
// ─────────────────────────────────────────────────────────────────────────────
loadDB();
writeBackup(); // backup on start

// Set up iptables chains
if (!DRY_RUN) {
  try {
    ensureIptablesChains();
    console.log('[iptables] accounting chains ready (IP:sport session-based)');
  } catch (e) {
    console.warn('[iptables] init failed (data tracking disabled):', e.message);
  }
}

// Start watching auth.log for SSH login/disconnect events
startAuthLogWatcher();

// Snapshot in-flight session counters every 5 minutes
setInterval(updateDataUsage, 5 * 60 * 1000);

// ─────────────────────────────────────────────────────────────────────────────
// Subscription portal server (runs on SUB_PORT, no auth — token-based)
// ─────────────────────────────────────────────────────────────────────────────
const subApp = express();
subApp.use(cors());
subApp.use(express.json());

// Serve sub.html at /sub.html
subApp.get('/sub.html', (req, res) => {
  if (fs.existsSync(SUB_FILE)) {
    res.sendFile(SUB_FILE);
  } else {
    res.status(404).send('<h2>sub.html not found. Place it alongside server.js.</h2>');
  }
});

// ── GET /sub/:token — public user info endpoint (no admin auth required) ──
subApp.get('/sub/:token', (req, res) => {
  const token = req.params.token;
  if (!token || token.length < 16) {
    return res.status(400).json({ ok: false, error: 'Invalid token' });
  }

  // Find user by subToken
  const u = db.users.find(x => x.subToken === token);
  if (!u) {
    return res.status(404).json({ ok: false, error: 'Account not found — token may have changed' });
  }

  // Build live session info
  const onlineSessions = [];
  for (const s of activeSessions.values()) {
    if (s.username === u.username) onlineSessions.push({ ip: s.clientIP, port: s.sport });
  }

  // Determine host for SSH command and NPV config
  let host = SERVER_HOST;
  if (!host) host = req.hostname || req.headers.host?.split(':')[0] || 'localhost';

  // Return safe subset — include password so NPV config and SSH details show it
  // (This is the user's own page, so showing their own credentials is correct)
  res.json({
    ok: true,
    host,
    user: {
      username:       u.username,
      status:         u.status,
      port:           u.port,
      maxConn:        u.maxConn,
      dataUsed:       u.dataUsed  || 0,
      dataIn:         u.dataIn    || 0,
      dataOut:        u.dataOut   || 0,
      dataLimit:      u.dataLimit || 0,
      expiry:         u.expiry    || '',
      created:        u.created   || '',
      lastSeen:       u.lastSeen  || 'never',
      sessions:       onlineSessions.length,
      online:         onlineSessions.length > 0,
      onlineSessions,
      nologin:        !!u.nologin,
      noforward:      !!u.noforward,
      x11:            !!u.x11,
      ipWhite:        !!u.ipWhite,
      ips:            u.ips || '',
      speedLimit:     u.speedLimit || 0,
      password:       u.password || '',  // user's own credential — safe on their page
    },
    subLink: `http://${host}:${SUB_PORT}/sub.html?token=${token}`,
  });
});

// ── POST /sub/:token/refresh-data — user-triggered data refresh ──
subApp.post('/sub/:token/refresh', (req, res) => {
  const u = db.users.find(x => x.subToken === req.params.token);
  if (!u) return res.status(404).json({ ok: false, error: 'Not found' });
  try { updateDataUsage(); } catch {}
  res.json({ ok: true });
});

subApp.listen(SUB_PORT, () => {
  console.log(`[sub-portal] Listening on http://localhost:${SUB_PORT}`);
});

app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════╗
║         ServerPanel Backend v1.0             ║
╠══════════════════════════════════════════════╣
║  Admin  : http://localhost:${PORT}               ║
║  SubPort: http://localhost:${SUB_PORT}              ║
║  DB     : ${DATA_FILE}
║  Backup : ${BACKUP_DIR}
║  Mode   : ${DRY_RUN ? 'DRY RUN (no real changes)' : 'LIVE (running as root)'}
╚══════════════════════════════════════════════╝
`);
  if (!DRY_RUN && process.getuid && process.getuid() !== 0) {
    console.warn('⚠  WARNING: Not running as root. Linux user commands will fail.');
    console.warn('   Run with:  sudo node server.js');
    console.warn('   Or dev mode: DRY_RUN=1 node server.js\n');
  }
});
